"""Tiny zero-dependency dashboard API; browser polls for fresh risk snapshots."""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from risk_engine.store import recent_snapshots

HTML = Path(__file__).with_name("index.html").read_bytes()


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/risk":
            try:
                body = json.dumps({"snapshots": recent_snapshots()}).encode()
                status = 200
            except Exception as error:
                body = json.dumps({"error": str(error)}).encode()
                status = 503
            content_type = "application/json"
        elif path == "/":
            body, status, content_type = HTML, 200, "text/html; charset=utf-8"
        else:
            body, status, content_type = b"Not found", 404, "text/plain"
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    print("Dashboard at http://localhost:8080", flush=True)
    ThreadingHTTPServer(("0.0.0.0", 8080), Handler).serve_forever()
