import tempfile
import unittest
from pathlib import Path

from risk_engine.config import INITIAL_POSITIONS
from risk_engine.risk import calculate_risk
from risk_engine.store import persist_batch, recent_snapshots


class RiskEngineTests(unittest.TestCase):
    def test_monte_carlo_tail_loss_and_reproducibility(self):
        history = {
            "AAA": [100 + i * 0.1 + (i % 3) * 0.2 for i in range(20)],
            "BBB": [50 + i * 0.05 - (i % 4) * 0.15 for i in range(20)],
        }
        first = calculate_risk({"AAA": 10, "BBB": 20}, history, scenarios=5000, seed=7)
        second = calculate_risk({"AAA": 10, "BBB": 20}, history, scenarios=5000, seed=7)
        self.assertEqual(first, second)
        self.assertGreater(first["var_95"], 0)
        self.assertGreaterEqual(first["cvar_95"], first["var_95"])
        self.assertEqual(first["observations"], 20)

    def test_insufficient_history(self):
        self.assertIsNone(calculate_risk({"AAA": 1}, {"AAA": [100] * 10}))

    def test_store_replay_does_not_double_count_positions(self):
        with tempfile.TemporaryDirectory() as folder:
            path = str(Path(folder) / "risk.db")
            rows = []
            for tick in range(12):
                for symbol, base in (("AAPL", 100), ("MSFT", 50), ("NVDA", 75), ("AMZN", 125)):
                    rows.append({
                        "topic": "trades", "partition": 0, "offset": len(rows),
                        "event_time": "2026-10-20T00:00:00+00:00", "tick": tick,
                        "symbol": symbol, "price": base + tick * .1 + (tick % 3) * .2,
                        "quantity_delta": 10 if tick == 0 and symbol == "AAPL" else 0,
                    })
            result = persist_batch(rows, 0, path=path, scenarios=1000)
            self.assertEqual(result["positions"]["AAPL"], INITIAL_POSITIONS["AAPL"] + 10)
            self.assertEqual(result["positions"]["MSFT"], INITIAL_POSITIONS["MSFT"])
            self.assertIsNone(persist_batch(rows, 0, path=path, scenarios=1000))
            snapshots = recent_snapshots(path)
            self.assertEqual(len(snapshots), 1)
            self.assertEqual(snapshots[0]["positions"]["AAPL"], INITIAL_POSITIONS["AAPL"] + 10)
            self.assertEqual(snapshots[0]["positions"]["MSFT"], INITIAL_POSITIONS["MSFT"])


if __name__ == "__main__":
    unittest.main()
