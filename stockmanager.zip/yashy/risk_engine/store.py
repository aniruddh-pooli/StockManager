"""Idempotent local sink for Spark micro-batches and dashboard readers."""
import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from risk_engine.config import INITIAL_POSITIONS
from risk_engine.risk import calculate_risk


def connect(path=None):
    target = Path(path or os.getenv("RISK_DB_PATH", "data/risk.db"))
    target.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(str(target), timeout=30)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA busy_timeout=30000")
    db.execute("PRAGMA journal_mode=WAL")
    db.executescript("""
        CREATE TABLE IF NOT EXISTS trades (
            topic TEXT NOT NULL,
            partition_id INTEGER NOT NULL,
            kafka_offset INTEGER NOT NULL,
            event_time TEXT NOT NULL,
            tick INTEGER NOT NULL,
            symbol TEXT NOT NULL,
            price REAL NOT NULL,
            quantity_delta INTEGER NOT NULL,
            PRIMARY KEY (topic, partition_id, kafka_offset)
        );
        CREATE INDEX IF NOT EXISTS trades_symbol_tick ON trades(symbol, tick DESC);
        CREATE TABLE IF NOT EXISTS risk_snapshots (
            batch_id INTEGER PRIMARY KEY,
            calculated_at TEXT NOT NULL,
            portfolio_value REAL NOT NULL,
            var_95 REAL NOT NULL,
            cvar_95 REAL NOT NULL,
            observations INTEGER NOT NULL,
            scenarios INTEGER NOT NULL,
            positions_json TEXT NOT NULL,
            prices_json TEXT NOT NULL
        );
    """)
    return db


def persist_batch(rows, batch_id, path=None, lookback=60, scenarios=5000):
    db = connect(path)
    try:
        if db.execute("SELECT 1 FROM risk_snapshots WHERE batch_id=?", (batch_id,)).fetchone():
            return None
        with db:
            db.executemany("""
                INSERT OR IGNORE INTO trades
                (topic, partition_id, kafka_offset, event_time, tick, symbol, price, quantity_delta)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, [
                (r["topic"], r["partition"], r["offset"], r["event_time"],
                 r["tick"], r["symbol"], r["price"], r["quantity_delta"])
                for r in rows
            ])
            positions = dict(INITIAL_POSITIONS)
            for row in db.execute("SELECT symbol, SUM(quantity_delta) AS quantity FROM trades GROUP BY symbol"):
                positions[row["symbol"]] = positions.get(row["symbol"], 0) + row["quantity"]
            tick_prices = {}
            for symbol in positions:
                latest = db.execute("""
                    SELECT tick, price FROM trades WHERE symbol=?
                    ORDER BY tick DESC LIMIT ?
                """, (symbol, (lookback + 1) * 2)).fetchall()
                tick_prices[symbol] = {r["tick"]: r["price"] for r in latest}
            held = [s for s, qty in positions.items() if qty]
            common = sorted(set.intersection(*(set(tick_prices[s]) for s in held)))[-(lookback + 1):] if held else []
            history = {s: [tick_prices[s][tick] for tick in common] for s in held}
            result = calculate_risk(positions, history, scenarios=scenarios, seed=batch_id)
            if result:
                db.execute("""
                    INSERT INTO risk_snapshots
                    (batch_id, calculated_at, portfolio_value, var_95, cvar_95,
                     observations, scenarios, positions_json, prices_json)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    batch_id, datetime.now(timezone.utc).isoformat(timespec="seconds"),
                    result["portfolio_value"], result["var_95"], result["cvar_95"],
                    result["observations"], result["scenarios"],
                    json.dumps(result["positions"]), json.dumps(result["prices"]),
                ))
            return result
    finally:
        db.close()


def recent_snapshots(path=None, limit=120):
    target = Path(path or os.getenv("RISK_DB_PATH", "data/risk.db"))
    if not target.exists():
        return []
    db = sqlite3.connect(f"file:{target}?mode=ro", uri=True, timeout=10)
    db.row_factory = sqlite3.Row
    try:
        rows = db.execute("""
            SELECT * FROM risk_snapshots ORDER BY batch_id DESC LIMIT ?
        """, (limit,)).fetchall()
        result = []
        for row in reversed(rows):
            item = dict(row)
            item["positions"] = json.loads(item.pop("positions_json"))
            item["prices"] = json.loads(item.pop("prices_json"))
            result.append(item)
        return result
    finally:
        db.close()

