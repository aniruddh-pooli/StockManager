"""Demo market and initial portfolio configuration."""
SYMBOLS = ("AAPL", "MSFT", "NVDA", "AMZN")
INITIAL_POSITIONS = {"AAPL": 40, "MSFT": 30, "NVDA": 60, "AMZN": 35}

