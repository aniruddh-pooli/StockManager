"""Send local risk snapshots to a Power BI PushStreaming semantic model."""
import os
import sqlite3
import time
from pathlib import Path

import msal
import requests

BASE = "https://api.powerbi.com/v1.0/myorg"
SCOPES = ["https://analysis.windows.net/powerbi/api/Dataset.ReadWrite.All"]
TABLE = "RiskSnapshots"
COLUMNS = [
    ("BatchId", "Int64"), ("CalculatedAt", "DateTime"),
    ("PortfolioValue", "Double"), ("VaR95", "Double"),
    ("CVaR95", "Double"), ("Observations", "Int64"),
    ("Scenarios", "Int64"),
]


class PowerBI:
    def __init__(self, client_id, tenant_id, state_dir):
        self.state_dir = Path(state_dir)
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.cache_path = self.state_dir / "powerbi_token_cache.json"
        cache = msal.SerializableTokenCache()
        if self.cache_path.exists():
            cache.deserialize(self.cache_path.read_text())
        self.cache = cache
        self.app = msal.PublicClientApplication(
            client_id, authority=f"https://login.microsoftonline.com/{tenant_id}",
            token_cache=cache)

    def token(self):
        accounts = self.app.get_accounts()
        result = self.app.acquire_token_silent(SCOPES, account=accounts[0]) if accounts else None
        if not result:
            flow = self.app.initiate_device_flow(scopes=SCOPES)
            if "user_code" not in flow:
                raise RuntimeError(f"Device login failed: {flow}")
            print(flow["message"], flush=True)
            result = self.app.acquire_token_by_device_flow(flow)
        if self.cache.has_state_changed:
            self.cache_path.write_text(self.cache.serialize())
            self.cache_path.chmod(0o600)
        if "access_token" not in result:
            raise RuntimeError(f"Power BI authentication failed: {result.get('error_description', result)}")
        return result["access_token"]

    def request(self, method, path, payload):
        response = requests.request(
            method, BASE + path,
            headers={"Authorization": f"Bearer {self.token()}"},
            json=payload, timeout=30)
        response.raise_for_status()
        return response.json() if response.content else None

    def dataset_id(self):
        target = self.state_dir / "powerbi_dataset_id.txt"
        if target.exists():
            return target.read_text().strip()
        result = self.request("POST", "/datasets?defaultRetentionPolicy=basicFIFO", {
            "name": "RiskPulse Live Risk",
            "defaultMode": "PushStreaming",
            "tables": [{"name": TABLE, "columns": [
                {"name": name, "dataType": kind} for name, kind in COLUMNS]}],
        })
        target.write_text(result["id"])
        print(f"Created Power BI semantic model: {result['id']}", flush=True)
        return result["id"]


def pending_rows(db_path, after_batch):
    if not Path(db_path).exists():
        return []
    db = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    db.row_factory = sqlite3.Row
    try:
        return db.execute("""
            SELECT batch_id, calculated_at, portfolio_value, var_95, cvar_95,
                   observations, scenarios FROM risk_snapshots
            WHERE batch_id > ? ORDER BY batch_id LIMIT 20
        """, (after_batch,)).fetchall()
    finally:
        db.close()


def main():
    client = os.getenv("POWERBI_CLIENT_ID")
    tenant = os.getenv("POWERBI_TENANT_ID")
    if not client or not tenant:
        raise SystemExit("Set POWERBI_CLIENT_ID and POWERBI_TENANT_ID first; see README.md")
    state_dir = Path(os.getenv("POWERBI_STATE_DIR", "data"))
    state_dir.mkdir(parents=True, exist_ok=True)
    bridge = PowerBI(client, tenant, state_dir)
    dataset_id = bridge.dataset_id()
    cursor_path = state_dir / "powerbi_last_batch.txt"
    last = int(cursor_path.read_text()) if cursor_path.exists() else -1
    print(f"Streaming to Power BI semantic model {dataset_id}", flush=True)
    while True:
        rows = pending_rows(os.getenv("RISK_DB_PATH", "data/risk.db"), last)
        if rows:
            payload = {"rows": [{
                "BatchId": row["batch_id"],
                "CalculatedAt": row["calculated_at"],
                "PortfolioValue": row["portfolio_value"],
                "VaR95": row["var_95"],
                "CVaR95": row["cvar_95"],
                "Observations": row["observations"],
                "Scenarios": row["scenarios"],
            } for row in rows]}
            try:
                bridge.request("POST", f"/datasets/{dataset_id}/tables/{TABLE}/rows", payload)
                last = rows[-1]["batch_id"]
                cursor_path.write_text(str(last))
                print(f"Pushed {len(rows)} snapshots through batch {last}", flush=True)
            except requests.HTTPError as error:
                print(f"Power BI push failed: {error}; retrying", flush=True)
                time.sleep(10)
                continue
        time.sleep(5)


if __name__ == "__main__":
    main()
