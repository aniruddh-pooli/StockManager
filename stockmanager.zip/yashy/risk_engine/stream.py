"""Spark Structured Streaming Kafka consumer with an idempotent SQLite sink."""
import os

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json
from pyspark.sql.types import DoubleType, IntegerType, LongType, StringType, StructField, StructType

from risk_engine.store import persist_batch

SCHEMA = StructType([
    StructField("event_id", StringType()),
    StructField("event_time", StringType()),
    StructField("tick", LongType()),
    StructField("symbol", StringType()),
    StructField("price", DoubleType()),
    StructField("quantity_delta", IntegerType()),
])


def main():
    spark = (SparkSession.builder.appName("FinancialRiskAnalytics")
             .config("spark.sql.shuffle.partitions", "2").getOrCreate())
    spark.sparkContext.setLogLevel("WARN")
    source = (spark.readStream.format("kafka")
              .option("kafka.bootstrap.servers", os.getenv("KAFKA_BOOTSTRAP_SERVERS", "kafka:9092"))
              .option("subscribe", "trades")
              .option("startingOffsets", "earliest")
              .load())
    parsed = (source.select(
        col("topic"), col("partition"), col("offset"),
        from_json(col("value").cast("string"), SCHEMA).alias("trade"))
        .select("topic", "partition", "offset", "trade.*")
        .where(col("event_time").isNotNull() & col("tick").isNotNull()
               & col("symbol").isNotNull() & (col("price") > 0)
               & col("quantity_delta").isNotNull()))

    def save(batch, batch_id):
        rows = [r.asDict() for r in batch.collect()]
        if rows:
            result = persist_batch(
                rows, batch_id,
                lookback=int(os.getenv("RISK_LOOKBACK_TICKS", "60")),
                scenarios=int(os.getenv("MC_SCENARIOS", "5000")),
            )
            if result:
                print(f"batch={batch_id} VaR={result['var_95']} CVaR={result['cvar_95']}", flush=True)

    query = (parsed.writeStream.foreachBatch(save)
             .option("checkpointLocation", "/app/checkpoints/trades")
             .trigger(processingTime="5 seconds").start())
    query.awaitTermination()


if __name__ == "__main__":
    main()

