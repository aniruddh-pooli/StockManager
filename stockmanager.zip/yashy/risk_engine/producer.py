"""Deterministic-looking but genuinely random correlated market and trade simulator."""
import json
import os
import random
import time
from datetime import datetime, timezone

import numpy as np
from kafka import KafkaProducer

from risk_engine.config import SYMBOLS

START_PRICES = np.array([220.0, 430.0, 135.0, 190.0])


def events(prices, tick, rng):
    """Emit one price observation per symbol per tick, with occasional trades."""
    common = rng.normal(0, 0.0008)
    shocks = common + rng.normal(0, [0.0012, 0.0010, 0.0018, 0.0013])
    prices *= np.exp(shocks)
    now = datetime.now(timezone.utc).isoformat(timespec="milliseconds")
    for i, symbol in enumerate(SYMBOLS):
        if rng.random() < 0.1:
            delta = int(rng.integers(1, 5)) * (1 if rng.random() < 0.55 else -1)
        else:
            delta = 0
        yield {
            "event_id": f"{tick}:{symbol}",
            "event_time": now,
            "tick": tick,
            "symbol": symbol,
            "price": round(float(prices[i]), 4),
            "quantity_delta": delta,
        }


def main():
    servers = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092").split(",")
    producer = KafkaProducer(
        bootstrap_servers=servers,
        value_serializer=lambda obj: json.dumps(obj).encode(),
        acks="all",
        retries=10,
    )
    rng = np.random.default_rng()
    prices = START_PRICES.copy()
    interval = float(os.getenv("PRODUCER_INTERVAL_SECONDS", "1"))
    tick = int(time.time() * 1000)
    while True:
        for event in events(prices, tick, rng):
            producer.send("trades", key=event["symbol"].encode(), value=event)
            print(json.dumps(event), flush=True)
        producer.flush()
        tick += 1
        time.sleep(interval)


if __name__ == "__main__":
    main()

