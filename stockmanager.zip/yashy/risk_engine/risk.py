"""Monte Carlo portfolio VaR/CVaR from synchronized recent price ticks."""
import numpy as np


def calculate_risk(positions, price_history, scenarios=5000, confidence=0.95, seed=42):
    """Return one-tick loss estimates; losses are positive when the portfolio falls.

    price_history maps symbol to price observations ordered oldest to newest.
    Missing observations are excluded until all held symbols have enough data.
    """
    held = sorted(symbol for symbol, quantity in positions.items() if quantity != 0)
    if not held:
        return None
    prices = [np.asarray(price_history.get(symbol, []), dtype=float) for symbol in held]
    if any(len(series) < 11 or np.any(series <= 0) for series in prices):
        return None
    count = min(len(series) for series in prices)
    returns = np.column_stack([np.diff(np.log(series[-count:])) for series in prices])
    means = returns.mean(axis=0)
    covariance = np.atleast_2d(np.cov(returns, rowvar=False))
    # A small diagonal ridge keeps nearly identical assets numerically stable.
    covariance += np.eye(len(held)) * 1e-12
    rng = np.random.default_rng(seed)
    simulated_returns = rng.multivariate_normal(means, covariance, size=scenarios)
    exposures = np.array([positions[s] * price_history[s][-1] for s in held], dtype=float)
    losses = -(np.exp(simulated_returns) - 1) @ exposures
    var = max(0.0, float(np.quantile(losses, confidence)))
    cvar = max(0.0, float(losses[losses >= np.quantile(losses, confidence)].mean()))
    return {
        "portfolio_value": round(float(exposures.sum()), 2),
        "var_95": round(var, 2),
        "cvar_95": round(cvar, 2),
        "observations": count,
        "scenarios": scenarios,
        "confidence": confidence,
        "positions": {s: int(positions[s]) for s in held},
        "prices": {s: round(float(price_history[s][-1]), 4) for s in held},
    }
